"recomb" <-
function(d)
  {
    0.5*(1-exp(-2*d))
  }

