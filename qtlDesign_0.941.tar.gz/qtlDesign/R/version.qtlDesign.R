"version.qtlDesign" <-
function()
  {
    0.941
  }

